# Dream Planning Board — Google AI Studio app

React + TypeScript app in the format Google AI Studio's **Build** mode uses: files at the root, an import map in `index.html`, no build step.

## Upload to Google AI Studio

1. Open https://aistudio.google.com and go to **Build**.
2. Upload `dream-planning-board-aistudio.zip` (the files are at the root of the zip).
3. The app opens in the preview. From there you can keep editing it with prompts, deploy it, or save it to GitHub.

## Files

```
index.html               import map (React 18, d3 7 from esm.sh) and all styles
index.tsx                entry point
App.tsx                  page layout and state (filters, board settings)
metadata.json            app name and description for AI Studio
types.ts                 data types
hooks.ts                 data loading, CSV replacement, tooltip and width hooks
lib/csv.ts               CSV, number and date parsing
lib/loaders.ts           sheet CSV → rows (plan, daily plan, capacity, orders)
lib/calcs.ts             KPIs, line load, line summary, order book
lib/format.ts            number/date formats and colours
components/Toolbar.tsx        board toolbar (views, search, filters, colour, dates, tracks, zoom)
components/PlanningBoard.tsx  the planning board and its legend
components/Summary.tsx        summary sentence and KPI tiles
components/Tables.tsx         line status, PO plan (sortable), order book
components/Charts.tsx         daily planned output, planned efficiency heatmap
components/DataPanel.tsx      "Update data" panel
data/*.ts                CSV exports of the sheet tabs, bundled as strings
```

## Updating the data

- **In the app:** open **Update data** at the bottom, and pick a fresh CSV export of the tab (Google Sheets: File → Download → Comma-separated values). It is kept in that browser until you press Restore.
- **For everyone:** replace the text inside the matching `data/*.ts` file with the new CSV contents.

The loaders find header rows by name (`Line No`, `Order Date`, `DATE`), so keep the column headings unchanged.

## How the numbers are worked out

| Figure | Definition |
| --- | --- |
| PSD / PED | Planned sewing start and end on the line. A PO marked "Running" starts on its first planned day. |
| Working days | Dates listed in the MANPOWER tab (holidays already removed). |
| Pcs / day | Line plan quantity ÷ working days from PSD to PED. |
| Produce minutes | Line plan quantity × SMV. |
| Sewn | Sewing Qty, or else "Production up to …" from the plan tab. |
| Sewing balance | Line plan quantity − sewn. |
| Available minutes | Manpower × working hours × 60, less NPT minutes per operator. |
| Planned efficiency | Produce minutes planned for a line on a day ÷ available minutes. |
| Days late | Plan ETD − updated ETD, in calendar days. Above zero means the plan ships after the buyer's date. |
