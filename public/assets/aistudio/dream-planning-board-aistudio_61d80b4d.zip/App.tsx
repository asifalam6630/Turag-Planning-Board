import { useMemo, useState } from 'react';
import type { BoardState, Filters } from './types';
import { useDashboardData } from './hooks';
import { bookStatus, lineLoad, lineSummary, poView, scopeKpi, unplanned } from './lib/calcs';
import { Toolbar, VIEW_PX } from './components/Toolbar';
import { BoardLegend, PlanningBoard } from './components/PlanningBoard';
import { KpiTiles, Takeaway } from './components/Summary';
import { LineStatusTable, OrderBook, PoTable } from './components/Tables';
import { DailyChart, Heatmap } from './components/Charts';
import { DataPanel } from './components/DataPanel';

const DEFAULT_FILTERS: Filters = { line: 'All', buyer: 'All', status: 'All' };
const DEFAULT_BOARD: BoardState = {
  view: 'week', px: VIEW_PX.week, multi: true, q: '', run: 'All', color: 'change', from: null, to: null, todayTick: 0
};

export default function App() {
  const { state, custom, replace, restore } = useDashboardData();
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const [board, setBoard] = useState<BoardState>(DEFAULT_BOARD);
  const [resetKey, setResetKey] = useState(0);

  const d = state.data;
  const derived = useMemo(() => {
    if (!d) return null;
    const pv = poView(d.plan);
    const load = lineLoad(d.plan, d.daily, d.manpower, d.hours, d.npt);
    const summary = lineSummary(d.plan, load);
    const calendar = [...new Set(d.manpower.map((r) => r.date))].sort();
    return {
      pv,
      load,
      summary,
      calendar,
      lines: summary.length ? summary.map((r) => r.line) : [...new Set(d.plan.map((r) => r.line))].sort((a, b) => a - b),
      book: bookStatus(d.orders),
      open: unplanned(d.orders, d.plan),
      buyers: [...new Set(d.plan.map((r) => r.buyer))].sort(),
      statuses: [...new Set(d.plan.map((r) => r.status))].sort()
    };
  }, [d]);

  const kpi = useMemo(() => (d && derived ? scopeKpi(d.plan, derived.pv, filters) : null), [d, derived, filters]);

  const reset = () => {
    setFilters(DEFAULT_FILTERS);
    setBoard({ ...DEFAULT_BOARD, px: board.px, view: board.view, multi: board.multi, color: board.color, todayTick: board.todayTick + 1 });
    setResetKey((k) => k + 1);
  };

  return (
    <div className="sl">
      <header id="overview">
        <h1>Dream Planning Board</h1>
        <p className="sl-sub">{d?.planTitle ?? 'Production plan'}</p>
        {kpi && <Takeaway k={kpi} />}
      </header>

      {d && derived && kpi ? (
        <>
          <section className="sl-sec" id="planning-board">
            <Toolbar
              filters={filters} setFilters={setFilters} board={board} setBoard={setBoard}
              lines={[...new Set(d.plan.map((r) => String(r.line)))].sort((a, b) => Number(a) - Number(b))}
              buyers={derived.buyers} statuses={derived.statuses}
              calMin={derived.calendar[0]} calMax={derived.calendar[derived.calendar.length - 1]}
              onReset={reset} resetKey={resetKey}
            />
            <p className="sl-cap">
              Columns are working days from the holiday calendar. Each card is one PO: sequence on the line, buyer, style and quantity,
              then PO, sewing start (green) to end (red), working days and pieces per day. A red dot means the plan ETD falls after the
              buyer's updated ETD. Select a card for details.
            </p>
            <BoardLegend plan={d.plan} mode={board.color} />
            <PlanningBoard plan={d.plan} pv={derived.pv} calendar={derived.calendar} lines={derived.lines} filters={filters} board={board} />
          </section>

          <KpiTiles k={kpi} />

          <section className="sl-sec" id="line-status">
            <h2>Line status</h2>
            <p className="sl-cap">
              Planned efficiency is plan minutes divided by available minutes (manpower × working hours × 60, less NPT) from a line's first
              start to its last end. "Free from" is the next working day after the line's last PO ends.
            </p>
            <LineStatusTable rows={derived.summary} filters={filters} />
          </section>

          <section className="sl-sec" id="daily-output">
            <h2>Daily planned output</h2>
            <p className="sl-cap">Pieces planned per working day, stacked by line. Follows the line, buyer and present status filters.</p>
            <DailyChart daily={d.daily} plan={d.plan} filters={filters} />
          </section>

          <section className="sl-sec" id="efficiency">
            <h2>Planned efficiency by line and day</h2>
            <p className="sl-cap">
              Each cell is one line on one working day. Darker means more of the line's available minutes are planned; red means over
              100%; grey means nothing is planned. Follows the line filter only.
            </p>
            <Heatmap load={derived.load} filters={filters} />
          </section>

          <section className="sl-sec" id="po-plan">
            <h2>PO plan</h2>
            <p className="sl-cap">Every PO on the line plan. Select a column heading to sort. Days late is plan ETD minus updated ETD; a positive number means the plan ships late.</p>
            <PoTable plan={d.plan} pv={derived.pv} filters={filters} />
          </section>

          <section className="sl-sec" id="order-book">
            <h2>Order book</h2>
            <OrderBook book={derived.book} open={derived.open} />
          </section>
        </>
      ) : null}

      <DataPanel custom={custom} replace={replace} restore={restore} error={state.status === 'error' ? state.message : null} />

      <details id="definitions">
        <summary>Definitions</summary>
        <dl>
          <dt>PSD / PED</dt><dd>Planned sewing start and end dates on the line, from the PRODUCTION PLAN tab. A PO marked "Running" starts on its first planned day.</dd>
          <dt>Working days</dt><dd>Dates listed in the MANPOWER tab, with holidays already removed.</dd>
          <dt>Produce minutes</dt><dd>Line plan quantity × SMV per piece.</dd>
          <dt>Sewn / balance</dt><dd>Sewn is Sewing Qty, or else "Production up to …" from the plan tab. Balance is line plan quantity minus sewn.</dd>
          <dt>Available minutes</dt><dd>Manpower × working hours × 60, less NPT minutes per operator.</dd>
          <dt>Planned efficiency</dt><dd>Produce minutes planned for a line on a day ÷ that day's available minutes.</dd>
          <dt>Days late</dt><dd>Plan ETD minus updated ETD, in calendar days. Above zero means the plan ships after the buyer's date.</dd>
        </dl>
      </details>
    </div>
  );
}
