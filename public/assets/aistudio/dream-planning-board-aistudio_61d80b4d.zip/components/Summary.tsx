import type { ScopeKpi } from '../types';
import { fd, int, usd } from '../lib/format';

export function Takeaway({ k }: { k: ScopeKpi }) {
  return (
    <p className="sl-take" id="takeaway">
      <b>{int(k.lines)}</b> sewing lines carry <b>{int(k.planQty)}</b> pcs on <b>{int(k.pos)}</b> POs, loaded until{' '}
      <b>{fd(k.lastPed)}</b>. <b className={k.late > 0 ? 'sl-late' : undefined}>{int(k.late)}</b> of these POs are planned to ship after the buyer's updated ETD.
    </p>
  );
}

export function KpiTiles({ k }: { k: ScopeKpi }) {
  return (
    <div className="sl-kpis" id="kpis">
      <div className="sl-kpi"><span className="lab">Planned quantity</span><span className="val">{int(k.planQty)}</span><span className="note">pcs on the line plan</span></div>
      <div className="sl-kpi"><span className="lab">POs on lines</span><span className="val">{int(k.pos)}</span><span className="note">purchase orders loaded</span></div>
      <div className="sl-kpi"><span className="lab">Sewing balance</span><span className="val">{int(k.sewBal)}</span><span className="note">pcs still to sew · {int(k.sewn)} sewn</span></div>
      <div className="sl-kpi"><span className="lab">Produce minutes</span><span className="val">{int(k.planMin)}</span><span className="note">plan qty × SMV</span></div>
      <div className="sl-kpi"><span className="lab">FOB value</span><span className="val">{usd(k.fobValue)}</span><span className="note">CM {usd(k.cmValue)}</span></div>
      <div className="sl-kpi"><span className="lab">ETD at risk</span><span className={'val' + (k.late > 0 ? ' sl-late' : '')}>{int(k.late)}</span><span className="note">POs with plan ETD after updated ETD</span></div>
    </div>
  );
}
