import type { TipState } from '../hooks';

export function Tooltip({ tip }: { tip: TipState | null }) {
  if (!tip) return null;
  return (
    <div className="sl-tip" style={{ left: tip.x, top: tip.y }} role="status">
      <strong>{tip.title}</strong>
      {tip.lines.map((l, i) => <span key={i}>{l}</span>)}
    </div>
  );
}
